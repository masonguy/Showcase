package lab3;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class TestInsertionSort {

	public static void main(String[] args) {
		
		int[] testArray1 = {0,1,3,2,5,2,2,2,2,7,9,8};	
		System.out.println(isSorted((InsertionSort.insertionSort(testArray1))));
		int[] testArray2 = {0,1,2,3,3,4,5,6,7,8,9,10};
		System.out.println(isSorted((testArray2)));
		int[] testArray3 = {3,2,1,0,5,0,0,0,0,0,0,4};
		int[] testArray4 = {1,2,3,4,5,0,0,0,0,0,0,0};
		System.out.println(sameElements(testArray3, testArray4));
		testFromConsole();
	}
	private static boolean isSorted(int[] arr) {
		for(int i = 0; i < arr.length-1; i++) {
			if(arr[i] > arr[i+1]) {
				return false;
			} 
		}
		return true;
	}
	private static boolean sameElements(int[] arr, int[] brr) {
		if(arr.length != brr.length) {
			return false;
		}
		HashMap<Integer, Integer> mapA = createMap(arr);
		HashMap<Integer, Integer> mapB = createMap(brr);
		if(!mapA.equals(mapB)) {
			return false;
		}
		/*for(Integer i : mapA.keySet()) {
			if(!mapA.get(i).equals((mapB).get(i))) {
				return false;
			}
		}*/
		return true;
	}
	private static void testFromConsole() {
		Scanner scanner = new Scanner(System.in);
		while(true) {
			int counter = 0;
			String numList = "";
			String input = scanner.nextLine();
			for(int i = 0; i < input.length(); i++) {
				if(Character.isDigit(input.charAt(i))) {
					counter++;
					numList += input.charAt(i);					
				}
			}	
			System.out.println(numList);
			int[] numbersArr = new int[counter];
			for(int j = 0; j < numList.length(); j++) {
				numbersArr[j] = Character.getNumericValue(numList.charAt(j));		
				}	
			System.out.print(Arrays.toString(numbersArr));
			}
		
		}
	
	private static HashMap<Integer, Integer> createMap(int[] arr) {
		HashMap<Integer, Integer> elements = new HashMap<Integer,Integer>();
		for(int i = 0; i < arr.length; i++) {
			if(elements.containsKey(arr[i])) {
				int value = elements.get(arr[i]);
				elements.put(arr[i], value+1);			
			}
			else {
				elements.put(arr[i], 1);
			}
		}
		return elements;
	}
}
