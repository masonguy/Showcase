package lab3;

public class InsertionSort {
	public static int[] insertionSort(int[] arr) {
		for(int i = 1; i < arr.length - 1; i++) {
			int j = i;
			int key = arr[i];
			while(j > 0 && arr[j-1] > key) {
				arr[j+1] = arr[j];
				j--;
			}
			arr[j+1] = key;
		}
		return arr;
	}
}
