// this programs purpose is to test the Insertion Sort class to make sure it is working as intended
// By Mason Rudolph 4/29/18
package lab3;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class TestInsertionSort {
	//main method
	public static void main(String[] args) {
		//command line inputs are put into array and tested by length
		TestInsertionSort testSort = new TestInsertionSort();
		int[] inputArray = new int[args.length];
		String[] inputString = args;	
		for(int i = 0; i < args.length; i++) {
			inputArray[i] = Integer.parseInt(inputString[i]);
		}
		if(inputString.length != 0) { //only run testFromConsole if their are no command line arguments
			for(int i =0; i < args.length; i++) {
				testSort.shuffleTest(inputArray[i]);
			}
		} else {
			testSort.testFromConsole();
		}
	}
	//checks to see if the given array is sorted, returns false if not sorted 
	private static boolean isSorted(int[] arr) {
		for (int i = 0; i < arr.length - 1; i++) {
			if (arr[i] > arr[i + 1]) {
				return false;
			}
		}
		return true;
	}
	//checks to see if both inputed arrays are comprised of the same number and identity of each element returns false if either of these are not equal
	private static boolean sameElements(int[] arr, int[] brr) {
		if (arr.length != brr.length) {
			return false;
		}
		//calls createMap which changes an array into a HashMap
		HashMap<Integer, Integer> mapA = createMap(arr);
		HashMap<Integer, Integer> mapB = createMap(brr);
		if (!mapA.equals(mapB)) {
			return false;
		}
		return true;
	}
	//Allows the user to input numbers that will test InsertionSort
	private static void testFromConsole() {
		Scanner scanner = new Scanner(System.in);
		while (true) {
			int counter = 0;
			String numList = "";
			String input = scanner.nextLine();
			for (int i = 0; i < input.length(); i++) { //this only grabs integers from the input to prevent an errors
				if (Character.isDigit(input.charAt(i))) {
					counter++;
					numList += input.charAt(i);
				}
			}
			int[] numbersArr = new int[counter];
			for (int j = 0; j < numList.length(); j++) {
				numbersArr[j] = Character.getNumericValue(numList.charAt(j));
			}
			int[] sortedNums = InsertionSort.insertionSort(numbersArr);
			if (isSorted(sortedNums) == true && sameElements(numbersArr, sortedNums) == true) { //check to see if InsertionSort is working as intended
				System.out.println("Passed Test");
			} else {
				System.out.println("FAILED Test");
			}
		}
	}
	//this method takes a length 'n' and creates an array of n length from 0 to n-1 and than shuffles the array so it can be sorted
	private static void shuffleTest(int arrLength) {
		int[] arr = new int[arrLength];
		for (int i = 0; i < arrLength; i++) { 
			arr[i] = i;
		}
		int[] shuffledArr = arr;
		Collections.shuffle(Arrays.asList(shuffledArr)); //shuffles the array
		InsertionSort.insertionSort(shuffledArr);
		if (arr.equals(shuffledArr)) { //checks if InsertionSort correctly unshuffled the array
			System.out.println("Passed Test");
		} else {
			System.out.println("FAILED Test");
		}
	}
	//this method changes an array to a HashMap
	private static HashMap<Integer, Integer> createMap(int[] arr) {
		HashMap<Integer, Integer> elements = new HashMap<Integer, Integer>();
		for (int i = 0; i < arr.length; i++) {
			if (elements.containsKey(arr[i])) {
				int value = elements.get(arr[i]);
				elements.put(arr[i], value + 1); //if key was already in the map increment its value by 1
			} else {
				elements.put(arr[i], 1); //if the value was not included already add 1 with a value of 1
			}
		}
		return elements;
	}
}