// This program adds records and searches through records in a collection
// By Mason Rudolph
// 4/21/18

package lab2;
import java.util.ArrayList;
public class Lab2 {

	public static void main(String[] args) {
	ArrayList<Record> records = new ArrayList<Record>();
	Record record1 = new Record("myBand", "birthDate", 1998 , 1);
	Record record2 = new Record("deathMetal", "burnFire", 2000, 3);
	RecordCollection recordCollection = new RecordCollection();
	//methods for the RecordCollection class
	recordCollection.addRecord(record1, "record1");
	recordCollection.searchArtist("myBand");
	recordCollection.searchYear(1998);
	recordCollection.printByYear(2000);
	recordCollection.totalRecords();
	//methods for the Record class
	record1.incCopies();
	record2.decCopies();
	record1.getBandName();
	record2.getTitle();
	record1.getCopies();
	record2.getYear();


	}

}
