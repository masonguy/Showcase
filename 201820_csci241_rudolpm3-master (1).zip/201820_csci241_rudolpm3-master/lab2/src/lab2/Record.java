package lab2;

public class Record {
	private String bandName, title;
	private int numCopies, year;
	public Record(String bandName, String title, int year, int numCopies){
		this.bandName = bandName;
		this.title = title;
		this.year = year;
		this.numCopies = numCopies;
	}
	public int incCopies() {
		System.out.println("Called method incCopies");
		return 0;
	}
	public int decCopies() {
		System.out.println("Called method decCopies");
		return 0;
	}
	public String getBandName() {
		System.out.println("Called method getBandName");
		return "";
	}
	public String getTitle() {
		System.out.println("Called method getTitle");
		return "";
	}
	public int getYear() {
		System.out.println("Called method getYear");
		return 0;
	}
	public int getCopies() {
		System.out.println("Called method getCopies");
		return 0;
	}
}
