
package lab2;
import java.util.ArrayList;
public class RecordCollection {
	//array list of records in collection
	ArrayList<Record> records = new ArrayList<Record>();
	//constructors
	public RecordCollection() {
		
	}
	public RecordCollection(ArrayList<Record> records) {
		this.records = records;
	}
	//add a record to a recordCollection
	public String addRecord(Record record, String name){
		System.out.println("Called method addRecord with argument "+name);
		return "";
	}
	//search the collection for records by a certain artist, than print them
	public String searchArtist(String artistName) {
		System.out.println("Called method searchArtist with argument "+artistName);
		return "";
	}
	//search the collection for records released in a certain year, than print them
	public int searchYear(int year) {
		System.out.println("Called method searchYear with argument "+year);
		return 0;
	}
	//print the collection starting with a certain year
	public String printByYear(int year) {
		System.out.println("Called method printByYear with argument "+year);
		return "";
	}
	//print the total amount of records in the collection
	public int totalRecords() { 
		System.out.println("Called method totalRecords");
		return 0;
	}
	
}
